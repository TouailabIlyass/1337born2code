/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   do_op.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: itouaila <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/08 10:48:28 by itouaila          #+#    #+#             */
/*   Updated: 2018/08/08 17:05:32 by itouaila         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef DO_OP_H
# define DO_OP_H
# include <unistd.h>

int		ft_add_i(int a, int b);
int		ft_sub_i(int a, int b);
int		ft_mult_i(int a, int b);
int		ft_div_i(int a, int b);
int		ft_mod_i(int a, int b);
int		ft_atoi(char *str);
void	ft_putnbr(int nbr);
void	ft_putchar(char c);

#endif
