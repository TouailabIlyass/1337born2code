/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: itouaila <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/08 10:54:05 by itouaila          #+#    #+#             */
/*   Updated: 2018/08/08 17:28:00 by itouaila         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "do_op.h"

int	ft_get_op_index(char c)
{
	int		i;
	char	*ops;

	ops = "+-*/%";
	i = 0;
	while (*(ops + i))
	{
		if(*(ops + i) == c)
			return (i);
		i++;
	}
	return (-1);
}

int	ft_is_valide(char *str)
{
	int i;
	int count;

	count = 0;
	i = 0;
	while (*str == ' ' || *str == '\t' || *str == '\n')
		str++;
	if (*str == '\0')
		return (0);
	if (*str == '-' || *str == '+')
		str++;
	while (*str)
	{
		if ((*str >= '0' && *str <='9'))
			count++;
		else
			break ;
		str++;
	}
	return (count != 0);
}

int	ft_is_operation(char *str)
{
	int i;
	int c;

	i = 0;
	c = 0;
	while (str[i])
	{
		if(ft_get_op_index(str[0]) != -1)
			c = 1;
		i++;
	}
	if (c == 1 && i == 1)
		return (1);
	return (0);
}

int	ft_do_op(int a, int b, int op_index)
{
	int (*f[5])(int, int);

	(f)[0] = &ft_add_i;
	(f)[1] = &ft_sub_i;
	(f)[2] = &ft_mult_i;
	(f)[3] = &ft_div_i;
	(f)[4] = &ft_mod_i;
	if (b == 0 && (op_index == 4  || op_index == 3))
	{
		if (op_index == 3)
			write(1, "Stop : division by zero", 24);
		else if (op_index == 4)
			write(1, "Stop : modulo by zero", 21);
		return (-1);
	}
	return ((f)[op_index](a, b));
}

int	main(int argc, char **argv)
{
	int		a;
	int		b;
	char	c;
	int 	f_index;

	if (argc != 4)
		return (0);
	if ((!ft_is_valide(argv[1]) && !ft_is_valide(argv[3])) || !ft_is_operation(argv[2]))
	{
		ft_putnbr(0);
		ft_putchar('\n');
		return (0);
	}
	a = ft_atoi(argv[1]);
	b = ft_atoi(argv[3]);
	c = argv[2][0];
	f_index = ft_get_op_index(c);
	if (f_index != -1)
	{
		a = ft_do_op(a, b, f_index);
		if (a != -1)
		
	write(1, "\n", 1);
	return (0);
}
