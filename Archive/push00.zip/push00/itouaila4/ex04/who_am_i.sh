#!/bin/bash

ldapwhoami -Q
