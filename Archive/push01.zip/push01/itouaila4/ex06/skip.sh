#!/bin/bash

ls -l | sed 'n;d'
